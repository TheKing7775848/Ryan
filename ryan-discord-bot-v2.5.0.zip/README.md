# 🤖 Ryan - Enterprise Discord Bot

**Ryan** is a high-performance, enterprise-grade Discord bot powered by `discord.js v14` and **Google Gemini AI** (Ryan AI).

---

## ✨ Features

- 🧠 **Ryan AI Assistant**: Server management intelligence, rule enforcement advice, text summarization, and multilingual translation powered by Gemini.
- 🛡️ **Advanced Moderation & AutoMod**: Anti-spam, anti-invite, anti-link, bad word filters, mention limits, and automated tiered punishments.
- 🎫 **Interactive Ticket System**: Embed panels with button creation, department categorization, automatic transcript generation, and role routing.
- 💰 **Economy & Virtual Shop**: Daily rewards, jobs, gambling, custom server shop items, and global leaderboards.
- 📈 **Leveling & XP System**: Chat activity rewards, custom rank cards, and automated role milestones.
- 🎉 **Giveaways & Live Polls**: Timed giveaways with interactive button entries, automated winner selection, and live visual poll tallies.
- 🎵 **Voice Music System**: High quality audio streaming, queue management, volume controls, and playback filters.
- 🚪 **Welcome & Verification**: Captcha/button verification gates, custom welcome embeds, and automated roles.
- 📊 **Audit Logging & Telemetry**: Comprehensive multi-category audit logs with color-coded severity.

---

## 🚀 Quick Start

### 1. Clone & Install Dependencies
```bash
git clone https://github.com/your-org/ryan-discord-bot.git
cd ryan-discord-bot
npm install
```

### 2. Environment Configuration
Copy `.env.example` to `.env` and provide your credentials:
```env
DISCORD_TOKEN=your_bot_token_here
CLIENT_ID=your_discord_application_id
GUILD_ID=your_development_guild_id
GEMINI_API_KEY=your_gemini_api_key
MONGODB_URI=mongodb+srv://user:pass@cluster.mongodb.net/ryan_bot
```

### 3. Deploy Slash Commands
```bash
npm run deploy:commands
```

### 4. Start the Bot
```bash
# Development (with auto-reload)
npm run dev

# Production
npm run build
npm start
```

---

## 🐳 Docker Deployment

```bash
docker-compose up -d --build
```
