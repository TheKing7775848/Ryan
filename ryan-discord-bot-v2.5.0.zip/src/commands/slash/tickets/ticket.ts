import { SlashCommandBuilder, ChatInputCommandInteraction, PermissionFlagsBits, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } from 'discord.js';
import { EMBED_COLORS } from '../../../constants/colors';

export default {
  data: new SlashCommandBuilder()
    .setName('ticket')
    .setDescription('Ticket system management')
    .addSubcommand(sub =>
      sub
        .setName('panel')
        .setDescription('Send a ticket creation panel into this channel')
        .addStringOption(opt => opt.setName('title').setDescription('Panel title').setRequired(false))
        .addStringOption(opt => opt.setName('description').setDescription('Panel instructions').setRequired(false))
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  async execute(interaction: ChatInputCommandInteraction) {
    const title = interaction.options.getString('title') || '🎫 Server Support & Assistance';
    const description = interaction.options.getString('description') || 
      'Need help, want to report an issue, or have a question? Click the button below to open a private ticket with our staff team!';

    const embed = new EmbedBuilder()
      .setColor(EMBED_COLORS.PRIMARY)
      .setTitle(title)
      .setDescription(description)
      .addFields(
        { name: '📋 Support Hours', value: '24/7 Monitored Queue', inline: true },
        { name: '🔒 Privacy', value: 'Private channel with Staff', inline: true }
      )
      .setFooter({ text: 'Ryan Ticket Dispatcher' });

    const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId('ticket_create_general')
        .setLabel('Open Ticket')
        .setStyle(ButtonStyle.Primary)
        .setEmoji('📩'),
      new ButtonBuilder()
        .setCustomId('ticket_create_billing')
        .setLabel('Billing Support')
        .setStyle(ButtonStyle.Secondary)
        .setEmoji('💳'),
      new ButtonBuilder()
        .setCustomId('ticket_create_report')
        .setLabel('Report Member')
        .setStyle(ButtonStyle.Danger)
        .setEmoji('🚨')
    );

    await interaction.channel?.send({ embeds: [embed], components: [row] });
    return interaction.reply({ content: '✅ Ticket panel successfully deployed!', ephemeral: true });
  },
};
