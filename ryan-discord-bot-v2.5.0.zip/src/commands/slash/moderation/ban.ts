import { SlashCommandBuilder, ChatInputCommandInteraction, PermissionFlagsBits, EmbedBuilder } from 'discord.js';
import { EMBED_COLORS } from '../../../constants/colors';

export default {
  data: new SlashCommandBuilder()
    .setName('ban')
    .setDescription('Ban a member from the server')
    .addUserOption(opt => opt.setName('user').setDescription('The member to ban').setRequired(true))
    .addStringOption(opt => opt.setName('reason').setDescription('Reason for the ban').setRequired(false))
    .addIntegerOption(opt => opt.setName('delete_messages_days').setDescription('Days of messages to delete (0-7)').setMinValue(0).setMaxValue(7))
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),

  async execute(interaction: ChatInputCommandInteraction) {
    const targetUser = interaction.options.getUser('user', true);
    const reason = interaction.options.getString('reason') || 'No reason provided';
    const deleteDays = interaction.options.getInteger('delete_messages_days') || 0;

    const member = await interaction.guild?.members.fetch(targetUser.id).catch(() => null);

    if (member && !member.bannable) {
      return interaction.reply({
        content: '❌ **Error**: I cannot ban this member. Their highest role is equal to or higher than mine.',
        ephemeral: true,
      });
    }

    // Attempt DM notification
    await targetUser.send(`🔨 You have been banned from **${interaction.guild?.name}** for: *${reason}*`).catch(() => null);

    await interaction.guild?.members.ban(targetUser.id, {
      reason: `${reason} (Banned by ${interaction.user.tag})`,
      deleteMessageSeconds: deleteDays * 86400,
    });

    const embed = new EmbedBuilder()
      .setColor(EMBED_COLORS.DANGER)
      .setTitle('🛡️ Member Banned')
      .addFields(
        { name: 'Target User', value: `${targetUser.tag} (${targetUser.id})`, inline: true },
        { name: 'Moderator', value: `${interaction.user.tag}`, inline: true },
        { name: 'Reason', value: reason, inline: false },
        { name: 'Purged Messages', value: `${deleteDays} days`, inline: true }
      )
      .setTimestamp();

    return interaction.reply({ embeds: [embed] });
  },
};
