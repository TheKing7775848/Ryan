import { SlashCommandBuilder, ChatInputCommandInteraction, EmbedBuilder } from 'discord.js';
import { RyanAIService } from '../../../ai/ryanAI';
import { EMBED_COLORS } from '../../../constants/colors';

export default {
  data: new SlashCommandBuilder()
    .setName('ryan')
    .setDescription('Interact with Ryan AI Assistant')
    .addSubcommand(sub =>
      sub
        .setName('ask')
        .setDescription('Ask Ryan AI any question, command advice, or server management help')
        .addStringOption(opt =>
          opt.setName('prompt').setDescription('Your question or prompt').setRequired(true)
        )
    )
    .addSubcommand(sub =>
      sub
        .setName('summarize')
        .setDescription('Summarize text, notes, or rules with Ryan AI')
        .addStringOption(opt =>
          opt.setName('text').setDescription('Text to summarize').setRequired(true)
        )
    )
    .addSubcommand(sub =>
      sub
        .setName('translate')
        .setDescription('Translate text into any language')
        .addStringOption(opt => opt.setName('language').setDescription('Target language (e.g. Spanish, French, Japanese)').setRequired(true))
        .addStringOption(opt => opt.setName('text').setDescription('Text to translate').setRequired(true))
    ),

  async execute(interaction: ChatInputCommandInteraction) {
    await interaction.deferReply();
    const subcommand = interaction.options.getSubcommand();

    if (subcommand === 'ask') {
      const prompt = interaction.options.getString('prompt', true);
      const answer = await RyanAIService.ask(prompt, {
        guildName: interaction.guild?.name,
        username: interaction.user.username,
        channelTopic: (interaction.channel as any)?.topic,
      });

      const embed = new EmbedBuilder()
        .setColor(EMBED_COLORS.PRIMARY)
        .setAuthor({
          name: 'Ryan AI Assistant',
          iconURL: interaction.client.user?.displayAvatarURL(),
        })
        .setTitle(`❓ Prompt: ${prompt.slice(0, 100)}`)
        .setDescription(answer)
        .setFooter({ text: 'Powered by Google Gemini 3.7 Flash • Ryan Bot Core' })
        .setTimestamp();

      return interaction.editReply({ embeds: [embed] });
    }

    if (subcommand === 'summarize') {
      const text = interaction.options.getString('text', true);
      const summary = await RyanAIService.summarize(text);

      const embed = new EmbedBuilder()
        .setColor(EMBED_COLORS.INFO)
        .setTitle('📑 Ryan AI Summary')
        .setDescription(summary)
        .setFooter({ text: 'Summarized with high accuracy' })
        .setTimestamp();

      return interaction.editReply({ embeds: [embed] });
    }

    if (subcommand === 'translate') {
      const targetLang = interaction.options.getString('language', true);
      const text = interaction.options.getString('text', true);
      const translation = await RyanAIService.translate(text, targetLang);

      const embed = new EmbedBuilder()
        .setColor(EMBED_COLORS.SUCCESS)
        .setTitle(`🌐 Translation (${targetLang})`)
        .addFields(
          { name: 'Original', value: text.slice(0, 1024) },
          { name: 'Translation', value: translation.slice(0, 1024) }
        )
        .setTimestamp();

      return interaction.editReply({ embeds: [embed] });
    }
  },
};
