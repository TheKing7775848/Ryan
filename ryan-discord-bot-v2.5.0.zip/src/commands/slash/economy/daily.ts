import { SlashCommandBuilder, ChatInputCommandInteraction, EmbedBuilder } from 'discord.js';
import { UserModel } from '../../../database/models/User';
import { EMBED_COLORS } from '../../../constants/colors';

const DAILY_REWARD = 250;
const COOLDOWN_MS = 24 * 60 * 60 * 1000; // 24 hours

export default {
  data: new SlashCommandBuilder()
    .setName('daily')
    .setDescription('Claim your daily currency allowance'),

  async execute(interaction: ChatInputCommandInteraction) {
    const userId = interaction.user.id;
    const guildId = interaction.guildId!;

    let user = await UserModel.findOne({ userId, guildId });
    if (!user) {
      user = await UserModel.create({ userId, guildId });
    }

    const now = Date.now();
    if (user.lastDaily && now - user.lastDaily.getTime() < COOLDOWN_MS) {
      const remainingMs = COOLDOWN_MS - (now - user.lastDaily.getTime());
      const hours = Math.floor(remainingMs / (1000 * 60 * 60));
      const minutes = Math.floor((remainingMs % (1000 * 60 * 60)) / (1000 * 60));

      return interaction.reply({
        content: `⏳ You have already claimed your daily reward! Come back in **${hours}h ${minutes}m**.`,
        ephemeral: true,
      });
    }

    user.balance += DAILY_REWARD;
    user.lastDaily = new Date();
    await user.save();

    const embed = new EmbedBuilder()
      .setColor(EMBED_COLORS.SUCCESS)
      .setTitle('💰 Daily Reward Claimed!')
      .setDescription(`You received **🪙 ${DAILY_REWARD} Coins**!\nYour new wallet balance is **🪙 ${user.balance} Coins**.`)
      .setFooter({ text: 'Keep coming back daily to build your fortune!' })
      .setTimestamp();

    return interaction.reply({ embeds: [embed] });
  },
};
