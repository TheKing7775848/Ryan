import mongoose, { Schema, Document } from 'mongoose';

export interface IUser extends Document {
  userId: string;
  guildId: string;
  balance: number;
  bank: number;
  xp: number;
  level: number;
  lastDaily?: Date;
  lastWork?: Date;
  inventory: {
    itemId: string;
    name: string;
    quantity: number;
    purchasedAt: Date;
  }[];
  isVerified: boolean;
  warningsCount: number;
}

const UserSchema = new Schema<IUser>({
  userId: { type: String, required: true, index: true },
  guildId: { type: String, required: true, index: true },
  balance: { type: Number, default: 250 },
  bank: { type: Number, default: 0 },
  xp: { type: Number, default: 0 },
  level: { type: Number, default: 1 },
  lastDaily: { type: Date },
  lastWork: { type: Date },
  inventory: [
    {
      itemId: String,
      name: String,
      quantity: { type: Number, default: 1 },
      purchasedAt: { type: Date, default: Date.now },
    },
  ],
  isVerified: { type: Boolean, default: false },
  warningsCount: { type: Number, default: 0 },
}, { timestamps: true });

UserSchema.index({ userId: 1, guildId: 1 }, { unique: true });

export const UserModel = mongoose.model<IUser>('User', UserSchema);
