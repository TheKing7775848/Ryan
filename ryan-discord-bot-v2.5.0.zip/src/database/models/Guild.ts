import mongoose, { Schema, Document } from 'mongoose';

export interface IGuild extends Document {
  guildId: string;
  prefix: string;
  language: string;
  modules: {
    moderation: boolean;
    ryanAi: boolean;
    economy: boolean;
    leveling: boolean;
    tickets: boolean;
    giveaways: boolean;
    music: boolean;
    logging: boolean;
    verification: boolean;
    welcome: boolean;
    automod: boolean;
  };
  automod: {
    antiSpam: boolean;
    antiInvites: boolean;
    antiLinks: boolean;
    badWordsFilter: boolean;
    badWordsList: string[];
    maxMentions: number;
    maxCapsPercentage: number;
    action: string;
  };
  welcome: {
    enabled: boolean;
    channelId?: string;
    message?: string;
    autoRoleId?: string;
  };
  verification: {
    enabled: boolean;
    type: string;
    channelId?: string;
    verifiedRoleId?: string;
  };
  tickets: {
    categoryChannelId?: string;
    supportRoleId?: string;
    logChannelId?: string;
  };
}

const GuildSchema = new Schema<IGuild>({
  guildId: { type: String, required: true, unique: true },
  prefix: { type: String, default: '!' },
  language: { type: String, default: 'en' },
  modules: {
    moderation: { type: Boolean, default: true },
    ryanAi: { type: Boolean, default: true },
    economy: { type: Boolean, default: true },
    leveling: { type: Boolean, default: true },
    tickets: { type: Boolean, default: true },
    giveaways: { type: Boolean, default: true },
    music: { type: Boolean, default: true },
    logging: { type: Boolean, default: true },
    verification: { type: Boolean, default: true },
    welcome: { type: Boolean, default: true },
    automod: { type: Boolean, default: true },
  },
  automod: {
    antiSpam: { type: Boolean, default: true },
    antiInvites: { type: Boolean, default: true },
    antiLinks: { type: Boolean, default: false },
    badWordsFilter: { type: Boolean, default: true },
    badWordsList: { type: [String], default: [] },
    maxMentions: { type: Number, default: 5 },
    maxCapsPercentage: { type: Number, default: 70 },
    action: { type: String, default: 'warn' },
  },
  welcome: {
    enabled: { type: Boolean, default: true },
    channelId: String,
    message: { type: String, default: 'Welcome to **{server}**, {user}! Read the rules to get started.' },
    autoRoleId: String,
  },
  verification: {
    enabled: { type: Boolean, default: true },
    type: { type: String, default: 'button' },
    channelId: String,
    verifiedRoleId: String,
  },
  tickets: {
    categoryChannelId: String,
    supportRoleId: String,
    logChannelId: String,
  },
}, { timestamps: true });

export const GuildModel = mongoose.model<IGuild>('Guild', GuildSchema);
