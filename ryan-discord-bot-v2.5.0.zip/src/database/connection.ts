import mongoose from 'mongoose';
import { config } from '../config/config';
import { logger } from '../utils/logger';

export async function connectDatabase(): Promise<void> {
  try {
    logger.info('Connecting to MongoDB database...');
    await mongoose.connect(config.MONGODB_URI);
    logger.info('MongoDB connection established successfully.');
  } catch (error) {
    logger.error('Failed to connect to MongoDB:', error);
    // Don't crash immediately in dev, allows offline fallback
  }
}
