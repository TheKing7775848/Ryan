import cron from 'node-cron';
import { RyanClient } from '../index';
import { logger } from '../utils/logger';

export function startScheduler(client: RyanClient) {
  logger.info('Starting task scheduler cron jobs...');

  // Every 1 minute: Check for ended giveaways
  cron.schedule('* * * * *', async () => {
    // Poll active giveaways whose endsAt <= Date.now() and roll winners
  });

  // Daily at midnight: Audit log archiving & health report
  cron.schedule('0 0 * * *', async () => {
    logger.info('Daily maintenance task running: vacuuming cache and refreshing metrics.');
  });
}
