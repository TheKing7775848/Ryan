export const EMBED_COLORS = {
  PRIMARY: 0x5865F2,   // Discord Blurple
  SUCCESS: 0x57F287,   // Discord Green
  WARNING: 0xFEE75C,   // Discord Yellow
  DANGER: 0xED4245,    // Discord Red
  INFO: 0x5865F2,      // Light Blurple
  DARK: 0x2B2D31,      // Discord Dark Theme
  GOLD: 0xF1C40F,      // Economy / VIP Gold
  PURPLE: 0x9B59B6,    // Leveling / Special
} as const;
