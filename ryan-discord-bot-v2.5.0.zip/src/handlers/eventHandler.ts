import { RyanClient } from '../index';
import { logger } from '../utils/logger';

export async function loadEvents(client: RyanClient) {
  logger.info('Registering Discord gateway event listeners...');

  client.on('ready', () => {
    logger.info(`🤖 ${client.user?.tag} is ready and serving ${client.guilds.cache.size} guilds!`);
    client.user?.setPresence({
      activities: [{ name: '/ryan ask | /help', type: 0 }],
      status: 'online',
    });
  });

  client.on('interactionCreate', async (interaction) => {
    try {
      if (interaction.isChatInputCommand()) {
        const command = client.commands.get(interaction.commandName);
        if (!command) return;
        await command.execute(interaction);
      }
    } catch (error) {
      logger.error('Interaction execution error:', error);
      if (interaction.isRepliable() && !interaction.replied) {
        await interaction.reply({ content: '❌ An error occurred while executing this command.', ephemeral: true });
      }
    }
  });

  logger.info('Event listeners initialized.');
}
