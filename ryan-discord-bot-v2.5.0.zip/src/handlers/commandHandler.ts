import { RyanClient } from '../index';
import { REST, Routes } from 'discord.js';
import { config } from '../config/config';
import { logger } from '../utils/logger';

export async function loadCommands(client: RyanClient) {
  logger.info('Loading Slash Commands into memory Collection...');
  // In full deployment, files from src/commands are dynamically imported
  // and stored into client.commands
}

export async function deploySlashCommands(commandsJson: any[]) {
  const rest = new REST({ version: '10' }).setToken(config.DISCORD_TOKEN);
  try {
    logger.info(`Deploying ${commandsJson.length} application (/) commands to Discord...`);
    if (config.GUILD_ID) {
      await rest.put(
        Routes.applicationGuildCommands(config.CLIENT_ID, config.GUILD_ID),
        { body: commandsJson }
      );
    } else {
      await rest.put(
        Routes.applicationCommands(config.CLIENT_ID),
        { body: commandsJson }
      );
    }
    logger.info('Slash commands deployed successfully.');
  } catch (error) {
    logger.error('Error deploying commands:', error);
  }
}
