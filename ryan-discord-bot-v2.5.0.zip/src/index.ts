import { Client, GatewayIntentBits, Partials, Collection } from 'discord.js';
import { config } from './config/config';
import { logger } from './utils/logger';
import { connectDatabase } from './database/connection';
import { loadEvents } from './handlers/eventHandler';
import { loadCommands } from './handlers/commandHandler';
import { startScheduler } from './scheduler/taskScheduler';

export class RyanClient extends Client {
  public commands: Collection<string, any> = new Collection();
  public cooldowns: Collection<string, Collection<string, number>> = new Collection();
  public buttons: Collection<string, any> = new Collection();
  public selectMenus: Collection<string, any> = new Collection();
  public modals: Collection<string, any> = new Collection();

  constructor() {
    super({
      intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.GuildMessageReactions,
        GatewayIntentBits.GuildVoiceStates,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.DirectMessages,
      ],
      partials: [
        Partials.Message,
        Partials.Channel,
        Partials.Reaction,
        Partials.User,
        Partials.GuildMember,
      ],
    });
  }

  public async start(): Promise<void> {
    try {
      logger.info('Initializing Ryan Discord Bot...');
      
      // 1. Connect to Database
      await connectDatabase();
      
      // 2. Load Commands & Components
      await loadCommands(this);
      
      // 3. Register Event Listeners
      await loadEvents(this);
      
      // 4. Start Background Scheduler (Giveaways, Reminders)
      startScheduler(this);
      
      // 5. Connect to Discord Gateway
      await this.login(config.DISCORD_TOKEN);
      logger.info('Ryan Bot connected successfully!');
    } catch (error) {
      logger.error('Fatal initialization error:', error);
      process.exit(1);
    }
  }
}

const client = new RyanClient();
client.start();

// Handle uncaught exceptions gracefully
process.on('unhandledRejection', (reason) => {
  logger.error('Unhandled Promise Rejection:', reason);
});

process.on('uncaughtException', (error) => {
  logger.error('Uncaught Exception:', error);
});
