import { ButtonInteraction, ChannelType, PermissionFlagsBits, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } from 'discord.js';
import { EMBED_COLORS } from '../constants/colors';

export async function handleTicketButtons(interaction: ButtonInteraction) {
  const { customId, guild, user } = interaction;

  if (customId.startsWith('ticket_create_')) {
    const category = customId.replace('ticket_create_', '');
    const ticketChannelName = `ticket-${user.username.toLowerCase().slice(0, 10)}-${Math.floor(Math.random() * 900 + 100)}`;

    const channel = await guild?.channels.create({
      name: ticketChannelName,
      type: ChannelType.GuildText,
      permissionOverwrites: [
        {
          id: guild.id,
          deny: [PermissionFlagsBits.ViewChannel],
        },
        {
          id: user.id,
          allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.AttachFiles],
        },
      ],
    });

    if (!channel) {
      return interaction.reply({ content: '❌ Failed to create ticket channel.', ephemeral: true });
    }

    const embed = new EmbedBuilder()
      .setColor(EMBED_COLORS.PRIMARY)
      .setTitle(`🎫 Ticket #${channel.name}`)
      .setDescription(`Hello ${user}, thank you for reaching out!\nA staff member will assist you shortly.\n\n**Category**: `${category.toUpperCase()}``)
      .setTimestamp();

    const controls = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId('ticket_close')
        .setLabel('Close Ticket')
        .setStyle(ButtonStyle.Danger)
        .setEmoji('🔒'),
      new ButtonBuilder()
        .setCustomId('ticket_claim')
        .setLabel('Claim Ticket')
        .setStyle(ButtonStyle.Success)
        .setEmoji('✋')
    );

    await channel.send({ content: `${user} Staff Team`, embeds: [embed], components: [controls] });
    return interaction.reply({ content: `✅ Ticket opened: ${channel}`, ephemeral: true });
  }

  if (customId === 'ticket_close') {
    await interaction.reply({ content: '🔒 Closing ticket in 5 seconds...' });
    setTimeout(async () => {
      await interaction.channel?.delete().catch(() => null);
    }, 5000);
  }

  if (customId === 'ticket_claim') {
    await interaction.reply({ content: `✋ This ticket has been claimed by ${user}!` });
  }
}
