import { GoogleGenAI } from '@google/genai';
import { config } from '../config/config';
import { logger } from '../utils/logger';

let aiInstance: GoogleGenAI | null = null;

function getAiClient(): GoogleGenAI {
  if (!aiInstance) {
    aiInstance = new GoogleGenAI({
      apiKey: config.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return aiInstance;
}

export class RyanAIService {
  private static SYSTEM_PROMPT = `You are Ryan AI, the official intelligent assistant built directly into the Ryan Discord Bot.
Your mission:
1. Provide helpful, concise, and friendly responses formatted with Discord Markdown (bold, codeblocks, bullet points).
2. Assist server moderators with conflict resolution, rule formulation, and toxicity triage.
3. Help users understand Discord permissions, bot commands, and server features.
4. Keep replies under 1,800 characters so they fit inside Discord's 2,000 character limit.
5. Maintain a professional, polite, and witty persona.`;

  public static async ask(userPrompt: string, context?: { guildName?: string; username?: string; channelTopic?: string }): Promise<string> {
    try {
      const ai = getAiClient();
      const contextualSystemPrompt = `${this.SYSTEM_PROMPT}\n\nCurrent Context: Guild: ${context?.guildName || 'Unknown'}, User: ${context?.username || 'User'}, Channel Topic: ${context?.channelTopic || 'General'}`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.7-flash',
        contents: userPrompt,
        config: {
          systemInstruction: contextualSystemPrompt,
          temperature: 0.7,
        },
      });

      return response.text?.trim() || "I couldn't process your request at this moment. Please try again.";
    } catch (error) {
      logger.error('Ryan AI query error:', error);
      return "⚠️ **Ryan AI Notice**: An error occurred while communicating with the intelligence service. Please check API configuration.";
    }
  }

  public static async analyzeModeration(messageContent: string, serverRules: string[]): Promise<{ isToxic: boolean; flagReason?: string; suggestedAction: 'NONE' | 'WARN' | 'MUTE' | 'KICK' | 'BAN'; explanation: string }> {
    try {
      const ai = getAiClient();
      const prompt = `Analyze the following Discord message against server rules.
Rules: ${JSON.stringify(serverRules)}
Message to evaluate: "${messageContent}"

Respond in strict JSON with schema:
{
  "isToxic": boolean,
  "flagReason": string | null,
  "suggestedAction": "NONE" | "WARN" | "MUTE" | "KICK" | "BAN",
  "explanation": string
}`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.7-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          temperature: 0.2,
        },
      });

      const parsed = JSON.parse(response.text || '{}');
      return {
        isToxic: !!parsed.isToxic,
        flagReason: parsed.flagReason || undefined,
        suggestedAction: parsed.suggestedAction || 'NONE',
        explanation: parsed.explanation || 'Analyzed by Ryan AI engine.',
      };
    } catch (error) {
      logger.error('Ryan AI moderation analysis error:', error);
      return {
        isToxic: false,
        suggestedAction: 'NONE',
        explanation: 'Moderation triage fallback.',
      };
    }
  }

  public static async summarize(text: string): Promise<string> {
    try {
      const ai = getAiClient();
      const response = await ai.models.generateContent({
        model: 'gemini-3.7-flash',
        contents: `Please provide a crisp, bulleted TL;DR summary for this Discord discussion or text:\n\n${text}`,
        config: {
          temperature: 0.4,
        },
      });
      return response.text?.trim() || 'Summary could not be generated.';
    } catch (error) {
      logger.error('Ryan AI summarize error:', error);
      return 'Failed to summarize text.';
    }
  }

  public static async translate(text: string, targetLanguage: string): Promise<string> {
    try {
      const ai = getAiClient();
      const response = await ai.models.generateContent({
        model: 'gemini-3.7-flash',
        contents: `Translate the following text into ${targetLanguage}. Provide ONLY the translation with no meta commentary:\n\n${text}`,
        config: {
          temperature: 0.3,
        },
      });
      return response.text?.trim() || text;
    } catch (error) {
      logger.error('Ryan AI translate error:', error);
      return text;
    }
  }
}
